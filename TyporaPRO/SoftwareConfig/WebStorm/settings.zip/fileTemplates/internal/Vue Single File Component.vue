<template>
    <div class='app'>
        #[[$END$]]#
    </div>
</template>
<script>
export default {
name: "${COMPONENT_NAME}"
}
</script>

<style scoped>

</style>